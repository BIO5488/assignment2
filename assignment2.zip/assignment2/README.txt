Question 1
{Your command with specific file names}


{Number of uniquely mapped reads}


{Number of multi mapped reads}


{Number of unmapped reads}


-
Question 2
{What is enriched in this dataset}
{Single nucleotide enrichment scores}
{Dinucleotide enrichment scores}
{Description of how enrichment scores were calculated}
{Assay, Explanation}
-
Comments:
{Things that went wrong or you can not figure out}
-
Suggestions:
{What programming and/or genomics topics should the TAs cover in the next class that would have made this assignment go smoother?}
-
